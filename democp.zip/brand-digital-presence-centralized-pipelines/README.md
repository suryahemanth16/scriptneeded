<h1>
 🚀 Centralized Pipelines - Mobile & Web Development
</h1>

| Version | Date of publish |
| ------- | ---- |
| 2.0.17 | 17 Aug 2024 |
| 2.0 | 20 Nov 2023 |

# 🛠️ Table of Contents
<!-- no toc -->
- [🛠️ Table of Contents](#️-table-of-contents)
  - [Understanding the Centralized Pipelines](#understanding-the-centralized-pipelines)
  - [Features of the Centralized Pipelines](#features-of-the-centralized-pipelines)
- [Centralized Pipelines Mobile](MOBILE.md) 
  - [Android Deployment](MOBILE.md#android-deployment)
  - [iOS Deployment](MOBILE.md#ios-deployment)
- [Centralized Pipelines Web](WEB.md)
- [Key benefits of Centralized Pipelines](WEB.md#key-benefits-of-centralized-pipelines)
- [GitHub Actions Workflow Diagram for Web Applications Development](#github-actions-workflow-diagram-for-web-applications-development)
  - [Technical Summary](#technical-summary)

## Understanding the Centralized Pipelines

The Centralized Pipelines are designed to streamline the build and deployment process for our applications. They provide a standardized and efficient way to build, test, and deploy code across different projects.

## Features of the Centralized Pipelines

- Automated build and deployment process
- Support for multiple programming languages and frameworks
- Easy integration with popular CI/CD platforms
- Scalable and customizable configurations

# Centralized Pipelines Mobile
[Centralized Pipelines Mobile](https://github.com/procter-gamble/brand-digital-presence-centralized-pipelines/blob/feat/mobile/MOBILE.md)

# Centralized Pipelines Mobile : Android
[Centralized Pipelines Mobile : Android](https://github.com/procter-gamble/brand-digital-presence-centralized-pipelines/blob/feat/mobile/MOBILE.md#android-deployment)

# Centralized Pipelines Mobile : iOS
[Centralized Pipelines Mobile : iOS](https://github.com/procter-gamble/brand-digital-presence-centralized-pipelines/blob/feat/mobile/MOBILE.md#ios-deployment)

# Centralized Pipelines Mobile : Web
[Centralized Pipelines Mobile : Web](https://github.com/procter-gamble/brand-digital-presence-centralized-pipelines/blob/feat/mobile/WEB.md)

# GitHub Actions Workflow Diagram for Web Applications Development

```mermaid
---
title: Centralized Pipelines - Build
---
graph LR
  subgraph Workflow
    Build_Job["Build Job"]
    subgraph Event_Triggers
      Build_Job -- workflow_call --> Inputs_Call
      Build_Job -- workflow_dispatch --> Inputs_Dispatch
    end
    subgraph Jobs
      Inputs_Call --> Init_Job["init"]
      Init_Job --> Compliance_Audit_Job["compliance-audit"]
      Compliance_Audit_Job --> Build_Job
      Build_Job --> Scanning_Job["scanning"]
      Build_Job --> Trigger_Deploy_Job["trigger-deploy"]
    end
  end
  subgraph Steps
    subgraph Init_Job_Steps
      Init_Step1["Init"]
    end
    subgraph Compliance_Audit_Job_Steps
      Compliance_Audit_Step1["Compliance Audit"]
    end
    subgraph Build_Job_Steps
      Build_Step1["Export variables from secret"]
      Build_Step2["Build"]
    end
    subgraph Scanning_Job_Steps
      Scanning_Step1["TQO SNYK Scan"]
    end
    subgraph Trigger_Deploy_Job_Steps
      Trigger_Deploy_Step1["Trigger Promote Job"]
    end
  end
  Inputs_Call --> Init_Step1
  Init_Step1 --> Compliance_Audit_Step1
  Compliance_Audit_Step1 --> Build_Step1
  Build_Step1 --> Build_Step2
  Build_Step2 --> Scanning_Step1
  Scanning_Step1 --> Trigger_Deploy_Step1
```

```mermaid
---
title: Centralized Pipelines - PR Verify
---
flowchart LR
prStart((PR Created<br/>Target branch:main))
prValidate[Validate Inputs]
prEnd((PR Verified))

subgraph prCompliance[Compliance Audit]
npm[NPM Audit]
credScan[Credentials Scanner]
end

subgraph prQuality[Quality Audit]
a11y[Accessibility]
end

prStart-->prValidate
prValidate-->prCompliance
prCompliance-->prQuality
prQuality-->prEnd
```

```mermaid
---
title: Centralized Pipelines - Promote & Deploy
---
flowchart LR
buildStart((Pushed to branch: main))
buildValidate[Validate Inputs]
build[Build]
deploy[Deploy]
buildEnd((Application Deployed))

subgraph buildCompliance[Compliance Audit]
npmBuild[NPM Audit]
credScanBuild[Credentials Scanner]
pipeline[Pipeline Integrity]
repo[Repository Integrity]
end

approval{Approval}

approval-->|Yes|build
approval-->|No|terminate((Terminate pipeline))

subgraph promote[Promote]
swap[Swap Slots]
end

buildStart-->buildValidate
buildValidate-->buildCompliance
buildCompliance-->approval

build-->deploy
deploy-->promote
promote-->buildEnd
```




## Technical Summary

The steps encompass a variety of actions, such as checking out code, setting up the environment, generating artifacts, performing audits and scans, exporting variables, and deploying to Azure. Conditional logic is applied to control the execution of specific steps based on environment variables or the success of previous jobs.

PowerShell and CLI commands are used to perform tasks such as unzipping artifacts, configuring app settings, retrieving values from GitHub using the `gh` CLI, and interacting with Azure resources using the Azure CLI (`az`).

The configuration files demonstrate a comprehensive automation solution, incorporating best practices for building, auditing, and deploying projects. Through the combination of GitHub Actions and Azure services, developers can streamline their workflows and ensure consistent and efficient project delivery.


