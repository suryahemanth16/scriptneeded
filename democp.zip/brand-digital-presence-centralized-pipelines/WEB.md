
<h1>
 🚀 Centralized Pipelines - Mobile & Web Development
</h1>

| Version | Date of publish |
| ------- | ---- |
| 2.0.17 | 17 Aug 2024 |
| 2.0 | 20 Nov 2023 |

# 🛠️ Table of Contents
- [🛠️ Table of Contents](#️-table-of-contents)
  - [Understanding the Centralized Pipelines](#understanding-the-centralized-pipelines)
  - [Features of the Centralized Pipelines](#features-of-the-centralized-pipelines)
  - [Required Inputs for Centralized Pipelines](#required-inputs-for-centralized-pipelines)
  - [Mandatory Variables to complete the Init process](#mandatory-variables-to-complete-the-init-process)
  - [Build Job](#build-job)
  - [Workflow Details](#workflow-details)
    - [Jobs](#jobs)
- [Build Job](#build-job-1)
  - [Structure of the `build.yml` File](#structure-of-the-buildyml-file)
  - [Inputs](#inputs)
- [Promote \& Deploy Job](#promote--deploy-job)
  - [Workflow Details](#workflow-details-1)
    - [Jobs](#jobs-1)
  - [Job: Promote](#job-promote)
- [PR Verify](#pr-verify)
  - [Overview](#overview)
    - [Event Trigger](#event-trigger)
    - [Secrets](#secrets)
    - [pr-verify job](#pr-verify-job)
- [Key benefits of Centralized Pipelines](#key-benefits-of-centralized-pipelines)
  
## Understanding the Centralized Pipelines

The Centralized Pipelines are designed to streamline the build and deployment process for our applications. They provide a standardized and efficient way to build, test, and deploy code across different projects.

## Features of the Centralized Pipelines

- Automated build and deployment process
- Support for multiple programming languages and frameworks
- Easy integration with popular CI/CD platforms
- Scalable and customizable configurations

## Required Inputs for Centralized Pipelines

To successfully run the Centralized Pipelines, you will need to provide the following inputs:

| **input** | **description** |
| ------- | ---- |
| GH_TOKEN | GitHub token required for authentication. |
| ADO_TOKEN | Azure DevOps token required for authentication. |
| ADO_USER_MAIL | Azure DevOps user email required for authentication. |
| run_id | Run ID for the workflow dispatch event. Please provide the run ID as a string. |

**Make sure to provide the correct values for these inputs when triggering the Centralized Pipelines workflow.**

## Mandatory Variables to complete the Init process

1. `RUN-MODE` - Mandatory variable, which defines type of RUN-MODE used to build the project (ex. static / ssr).
2. `SITE_LANG` - Mandatory variable, which defines the language of the website (ex. en-us).
3. `DDA_NAME` - Mandatory variable used to define the Digital Delivery Agency (ex. P&G).
4. `WEB_APP_NAME` - Mandatory variable to establish connectivity with the Azure Web App service.
5. `ENVIRONMENT` - Mandatory variables used to define the working environment (ex. Production / Staging / Development)

## Build Job

This documentation provides an overview of the Build Job workflow. The workflow is triggered by the `workflow_call` and `workflow_dispatch` events.

## Workflow Details

### Jobs

The workflow consists of multiple jobs:

1. **init**: Initializes the workflow and runs the necessary setup using the `procter-gamble/brand-digital-presence-centralized-pipelines/web/actions/init@latest` action.

2. **compliance-audit**: Performs a compliance audit using the `procter-gamble/brand-digital-presence-centralized-pipelines/web/actions/audit/compliance@latest` action. This job depends on the successful completion of the **init** job.

3. **build**: Builds the project using the `procter-gamble/brand-digital-presence-centralized-pipelines/web/actions/build@latest` action. This job depends on the successful completion of both the **init** and **compliance-audit** jobs. It exports variables from a secret and specifies the desired Node.js version using the `node-version` input.

4. **scanning**: Performs vulnerability scanning using the `procter-gamble/de-atom-library@snyk-main` action. This job depends on the successful completion of the **init**, **compliance-audit**, and **build** jobs. It performs a TQO SNYK scan and requires the `SNYK_TOKEN` secret.

5. **trigger-deploy**: Triggers the deploy and promote workflow. This job depends on the successful completion of all previous jobs. It sets variables using the `procter-gamble/brand-digital-presence-centralized-pipelines/web/actions/variables/set@latest` action and triggers the `promote-deploy.yml` workflow using the GitHub API.


**Please note that this documentation provides an overview of the Build Job workflow, and it's essential to consult the actual workflow file for the most up-to-date and accurate information.**


# Build Job

## Structure of the `build.yml` File

The `build.yml` file follows a YAML syntax and consists of different sections and configurations. Here is an overview of the main sections:

1. **Environment**: This section defines the environment variables required for the build process.
2. **Steps**: This section specifies the sequence of steps to be executed during the build and deployment process.
3. **Artifacts**: This section defines the artifacts generated by the build process.

For detailed information on each section and their configurations, please refer to the specific sections in this documentation.

This section defines the workflow for the Build Job. It consists of multiple jobs that perform various steps to build, audit, and deploy the project.


## Inputs

The workflow takes the following inputs:

- `run_id`: The ID of the run (required).


# Promote & Deploy Job

This documentation provides an overview of the Promote & Deploy Job workflow. The workflow is triggered by the `workflow_call` event.

## Workflow Details

### Jobs

The workflow consists of two jobs:

1. **Deploy**: Deploys the application to Azure. This job downloads the artifact, performs Azure login, and deploys the application to the appropriate Azure environment based on the specified conditions.

2. **Promote**: Promotes the application to production and performs additional tasks such as updating environment variables and purging the CDN. This job is triggered only if the branch name is `main`. It swaps the deployment slot with the production environment, updates environment variables, and purges the CDN if the necessary conditions are met.

**Please note that this documentation provides an overview of the Promote & Deploy Job workflow, and it's essential to consult the actual workflow file for the most up-to-date and accurate information.**



## Job: Promote

The `promote` job is the main job of this workflow and it runs on the `ubuntu-latest` GitHub hosted runner. It includes the following steps:

1. **Get the Run_ID**: This step outputs the `run_id` provided as input to the workflow.
2. **Download Artifact**: This step downloads the artifact named `dist` using the `actions/download-artifact@v4` action, authenticated with the provided `GH_TOKEN`.
3. **Azure Login**: This step logs into Azure using the `azure/login@v1.6.1` action with the provided `AZURE_CREDENTIALS`.
4. **Unzip the artifact**: This step unzips the downloaded artifact and removes the zip file.
5. **Export variables from secret**: This step exports the required and optional variables.
6. **Deploy to Azure Non Production**: If the environment is not `production`, this step deploys the application to Azure non-production environment using the `azure/webapps-deploy@v3` action.
7. **Deploy to Azure Production**: If the environment is `production`, this step deploys the application to Azure production environment using the `azure/webapps-deploy@v3` action.
8. **PowerShell List of Values**: This step lists the values using PowerShell and sets the application settings on Azure web app.
9. **Auto Slot Swap**: If the environment is `production`, this step swaps the slot on Azure web app with the production slot.

This workflow provides a robust way to promote and deploy applications on Azure by running jobs and steps based on specific conditions. It shows how GitHub Actions can be used for complex CI/CD scenarios.

# PR Verify

This section defines the workflow for PR verification. It runs on certain events and performs various steps to verify pull requests.

## Overview

This workflow is designed to run a series of checks and scans whenever a pull request (PR) is verified. It utilizes several steps including setting up the environment, installing dependencies, and running quality checks and security scans.

### Event Trigger

- `workflow_call`: The workflow is triggered when a workflow is called.

### Secrets

The following secrets are required for this workflow:

- `GH_TOKEN`: GitHub token required for authentication.
- `ADO_TOKEN`: Azure DevOps token required for authentication.
- `ADO_USER_MAIL`: Azure DevOps user email required for authentication.


### pr-verify job

- Name: PR Verify
- Runs on: `ubuntu-latest`
- Steps:
  1. **Checkout**: Checks out the code from the repository.
  2. **Setup Node.js**: Sets up the Node.js environment.
  3. **Npmrcgen**: Generates the `.npmrc` file using custom action `procter-gamble/brand-digital-presence-centralized-pipelines/web/actions/npmrcgen@latest`.
     - Inputs:
       - `gh-token`: GitHub token (`GH_TOKEN`) from secrets.
       - `ado-token`: Azure DevOps token (`ADO_TOKEN`) from secrets.
       - `ado-user-mail`: Azure DevOps user email (`ADO_USER_MAIL`) from secrets.
  4. **Get npm cache directory**: Retrieves the npm cache directory path.
  5. **Use npm cache**: Caches the npm dependencies.
  6. **Npm clean install**: Performs a clean installation of npm packages.
     - Environment Variables:
       - `workingDir`: Specifies the working directory.
       - `command`: Specifies the command to be executed (`ci`).
  7. **Npm check-quality:ci**: Runs the npm check-quality command in CI mode.
  8. **TQO SNYK scan**: Performs a Snyk scan using the custom action `procter-gamble/de-pqe-qo-imo-gh_actions_templates@snyk.v2`.
     - Inputs:
       - `SNYK_TOKEN`: Snyk token (`SNYK_TOKEN`) from secrets.

# Key benefits of Centralized Pipelines

**Centralized Pipelines**, in the context of Continuous Integration/Continuous Deployment (CI/CD), are a design approach where all the build, test, and deployment stages are handled through a single, unified pipeline. This method provides a centralized overview and control of the entire application delivery process.

Key benefits of Centralized Pipelines include:

- **Standardization**: All projects follow the same steps for build, test, and deployment, which enforces consistency and reduces errors caused by discrepancies in individual pipelines.
- **Ease of maintenance**: Changes to the pipeline, such as updates to build scripts or deployment processes, only need to be made in one place.
- **Visibility**: All projects' build, test, and deployment status can be monitored from a single location, making it easier to identify and troubleshoot issues.

This approach is often used in large organizations with multiple projects, where maintaining consistency and visibility across all projects is crucial.
