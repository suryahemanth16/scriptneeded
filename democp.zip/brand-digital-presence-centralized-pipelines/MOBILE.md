<h1>
 🚀 Centralized Pipelines - Mobile & Web Development
</h1>

| Version | Date of publish |
| ------- | ---- |
| 2.0.17 | 17 Aug 2024 |
| 2.0 | 20 Nov 2023 |

# 🛠️ Table of Contents
- [🛠️ Table of Contents](#️-table-of-contents)
  - [Understanding the Centralized Pipelines](#understanding-the-centralized-pipelines)
  - [Features of the Centralized Pipelines](#features-of-the-centralized-pipelines)
- [\[Centralized Pipelines\] Mobile](#centralized-pipelines-mobile)
  - [\[Centralized Pipelines\] Mobile : **Android**](#centralized-pipelines-mobile--android)
    - [Android Deployment](#android-deployment)
    - [Workflow Details](#workflow-details)
    - [Jobs](#jobs)
      - [Environment Variables](#environment-variables)
      - [Steps](#steps)
- [\[Centralized Pipelines\] Mobile](#centralized-pipelines-mobile-1)
  - [\[Centralized Pipelines\] Mobile : **iOS**](#centralized-pipelines-mobile--ios)
    - [iOS Deployment](#ios-deployment)
    - [Workflow Details](#workflow-details-1)
    - [Jobs](#jobs-1)
      - [Environment Variables](#environment-variables-1)
      - [Steps](#steps-1)

## Understanding the Centralized Pipelines

The Centralized Pipelines are designed to streamline the build and deployment process for our applications. They provide a standardized and efficient way to build, test, and deploy code across different projects.

## Features of the Centralized Pipelines

- Automated build and deployment process
- Support for multiple programming languages and frameworks
- Easy integration with popular CI/CD platforms
- Scalable and customizable configurations

# [Centralized Pipelines] Mobile

## [Centralized Pipelines] Mobile : **Android**

### Android Deployment

This documentation provides an overview of the Android deployment process for a mobile application. The deployment workflow is defined using GitHub Actions, allowing for automated builds and releases.

### Workflow Details

The deployment workflow is triggered by two events: `workflow_call` and `workflow_dispatch`. This means that the workflow can be manually triggered or called by another workflow.

### Jobs

The workflow consists of a single job named "Build Android Mobile Application". This job runs on macOS 14.

#### Environment Variables

The following environment variables are defined for the job:

- `JAVA_VERSION`: Specifies the Java version to use (set to "18.0.0").
- `FLUTTER_VERSION`: Specifies the Flutter version to use (set to "3.19.2").
- `FLUTTER_CHANNEL`: Specifies the Flutter channel to use (set to "stable").
- `BUILD_TOOLS_VERSION`: Specifies the Android build tools version to use (set to "34.0.0").
- `SSH_KEY`: SSH key for authentication (stored in secrets).
- `SSH_AUTH_SOCK`: Path to the SSH agent socket.

#### Steps

The job consists of the following steps:

1. **Checkout**: Checks out the repository using the `actions/checkout@v4` action, using the GitHub token stored in secrets for authentication.
2. **Setup SSH with a passphrase**: Sets up SSH authentication with a passphrase using the provided SSH key and passphrase stored in secrets.
3. **Setup Java**: Sets up the Java environment using the `actions/setup-java@v1` action, specifying the Java version.
4. **Load Google Service file**: Loads the Google Service file by storing the contents of the `GOOGLE_SERVICES` secret in the specified location.
5. **Setup Flutter**: Sets up the Flutter environment using the `subosito/flutter-action@v2` action, specifying the Flutter version and channel.
6. **Flutter clean**: Cleans the Flutter project using the `flutter clean` command.
7. **Flutter precache**: Runs `flutter config --no-analytics` and `flutter precache` to pre-cache Flutter dependencies.
8. **Flutter pub get**: Runs `flutter pub get` to fetch the project dependencies, using the `SSH_KEY` secret for authentication.
9. **Build all JSON files**: Builds all JSON files using the `flutter pub run build_runner build --delete-conflicting-outputs` command.
10. **Build Android Release PRODUCTION APK**: Builds the Android release APK for the `dev` flavor using the `flutter build apk` command, specifying the target platform, flavor, and entry point.
11. **Sign PRODUCTION APK**: Signs the release APK using the `r0adkll/sign-android-release@v1` action. The signing configuration is provided through secrets.
12. **Upload Artifact**: Uploads the signed APK as an artifact using the `actions/upload-artifact@v3` action.


**Please note that this documentation provides an overview of the Android deployment workflow, and it's essential to consult the actual workflow file for the most up-to-date and accurate information.**



# [Centralized Pipelines] Mobile

## [Centralized Pipelines] Mobile : **iOS**

### iOS Deployment

This documentation provides an overview of the iOS deployment process for a mobile application. The deployment workflow is defined using GitHub Actions, enabling automated builds and releases.

### Workflow Details

The deployment workflow is triggered by the `workflow_call` event.

### Jobs

The workflow consists of a single job named "Build iOS Mobile Application". This job runs on macOS 14.

#### Environment Variables

The following environment variables are defined for the job:

- `FLUTTER_VERSION`: Specifies the Flutter version to use (set to "3.19.2").
- `FLUTTER_CHANNEL`: Specifies the Flutter channel to use (set to "stable").
- `WORKING_DIR`: Specifies the working directory for the build process.
- `SSH_AUTH_SOCK`: Path to the SSH agent socket.

#### Steps

The job consists of the following steps:

1. **Checkout**: Checks out the repository using the `actions/checkout@v4` action, using the GitHub token stored in secrets for authentication.

2. **Setup SSH with a passphrase**: Sets up SSH authentication with a passphrase using the provided SSH key and passphrase stored in secrets.

3. **Install Apple Certificate**: Uses the `apple-actions/import-codesign-certs@v1` action to install the Apple certificate required for code signing.

4. **Install the provisioning profile**: Installs the provisioning profile required for iOS app distribution.

5. **Setup Flutter**: Sets up the Flutter environment using the `subosito/flutter-action@v2` action, specifying the Flutter version and channel.

6. **Flutter clean**: Cleans the Flutter project using the `flutter clean` command.

7. **Flutter pub get**: Runs `flutter pub get` to fetch the project dependencies, using the `SSH_KEY` secret for authentication.

8. **Build iOS**: Builds the iOS app for the `dev` flavor using the `flutter build ios` command, specifying the target flavor and entry point.

9. **Build resolve Swift dependencies**: Resolves Swift dependencies using `xcodebuild`.

10. **Prepare iOS IPA file**: Creates a directory named "Payload" in the specified working directory.

11. **Move .app to Payload**: Moves the generated `.app` file to the "Payload" directory.

12. **Zip output**: Zips the "Payload" directory to create the iOS IPA file.

13. **Upload iOS**: Uploads the iOS IPA file as an artifact using the `actions/upload-artifact@v4` action.

**Please note that this documentation provides an overview of the iOS deployment workflow, and it's essential to consult the actual workflow file for the most up-to-date and accurate information.**

