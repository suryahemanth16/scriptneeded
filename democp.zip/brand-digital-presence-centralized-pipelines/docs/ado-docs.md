# GitHub Actions migration for Centralized Pipelines

Repository to migrate Azure DevOps Centralized Pipelines to GitHub actions

## Table of Contests

1. [Configuration for GitHub actions](README.md#configuration-for-github-actions)
2. [Command to update the Environment variables](README.md#command-to-update-the-environment-variables)
3. [Running the audit command](README.md#running-the-audit-command)
4. [Perform a dry run of Azure DevOps to build pipeline to GitHub Actions](README.md#perform-a-dry-run-of-azure-devops-to-build-pipeline-to-github-actions)
5. [Azure Pipelines - Migration to GitHub Actions](README.md#azure-pipelines---migration-to-github-actions)
6. [.github/workflows/build-deploy.yml](README.md#githubworkflowsbuild-deployyml)
7. [.github/workflows/build-job.yml](README.md#githubworkflowsbuild-jobyml)
8. [.github/workflows/compliance-audit-job.yml](README.md#githubworkflowscompliance-audit-jobyml)
9. [.github/workflows/compliance-only.yml](README.md#githubworkflowscompliance-onlyyml)
10. [.github/workflows/deploy-job.yml](README.md#githubworkflowsdeploy-jobyml)
11. [.github/workflows/hello_world.yml](README.md#githubworkflowshello_worldyml)
12. [.github/workflows/init-job.yml](README.md#githubworkflowsinit-jobyml)
13. [.github/workflows/init-pr-verify-job.yml](README.md#githubworkflowsinit-pr-verify-jobyml)
14. [.github/workflows/pr-verify-job.yml](README.md#githubworkflowspr-verify-jobyml)
15. [.github/workflows/pr-verify.yml](README.md#githubworkflowspr-verifyyml)
16. [.github/workflows/promote-job.yml](README.md#githubworkflowspromote-jobyml)
17. [.github/workflows/quality-job.yml](README.md#githubworkflowsquality-jobyml)
18. [.github/workflows/rollback.yml](README.md#githubworkflowsrollbackyml)
19. [.github/workflows/test-action.yml](README.md#githubworkflowstest-actionyml)


## 1. Configuration for GitHub actions.
Configure Envirnoment local files with the credentials:

`gh actions-importer configure`

- Which CI providers are you configuring?: Azure DevOps
Enter the following values (leave empty to omit):
- Personal access token for GitHub: **********************************************************
- Base url of the GitHub instance: https://github.com/
- Personal access token for Azure DevOps: ****************************************************
- Base url of the Azure DevOps instance: http://dev.azure.com
- Azure DevOps organization name: pg-consumer
- Azure DevOps project name: MW-Framework

Environment variables successfully updated.

## 2. Command to update the Environment variables

`gh actions-importer update`

Please ensure docker is installed and the docker daemon is running.

## 3. Running the audit command.

To perform an audit of an Azure DevOps organization, run the following command in your terminal:

`gh actions-importer audit azure-devops --output-dir tmp/audit`

## 4. Perform a dry run of Azure DevOps to build pipeline to GitHub Actions

To perform a dry run of migrating your Azure DevOps build pipeline to GitHub Actions, run the following command in your terminal, replacing pipeline_id with the ID of the pipeline you are converting.

`gh actions-importer dry-run azure-devops pipeline --pipeline-id :pipeline_id --output-dir tmp/dry-run`


## 5. Azure Pipelines - Migration to GitHub Actions

## 6. .github/workflows/build-deploy.yml
### Link to the repository file: 

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/build-deploy.yml


```mermaid

  flowchart LR
      A0(Init) --> 
      B0(Audit) --> 
      C0(Build) --> 
      D0(Quality) --> 
      E0(Approval) --> 
      F0(Deploy) --> 
      G0(Promote)

```

### Error: 
        CDN_PROFILE="$(appCdnProfileName)"
        CDN_ENDPOINT="$(appCdnEndpointName)"
        
        if [ -z $CDN_PROFILE ] && [ -z $CDN_ENDPOINT ]
        then
        echo 'Name of CDN Profile and CDN endpoint not provided'
        echo "##vso[task.setvariable variable=profile;isOutput=true]"
        echo "##vso[task.setvariable variable=endpoint;isOutput=true]"
        exit 0
        else
        echo 'Name of CDN Profile and CDN endpoint provided'
        echo "##vso[task.setvariable variable=profile;isOutput=true]$(appCdnProfileName)"
        echo "##vso[task.setvariable variable=endpoint;isOutput=true]$(appCdnEndpointName)"
        exit 0
        fi
        exit 0 
        shell: /usr/bin/bash --noprofile --norc -e -o pipefail {0}
        env:
        mwAzureCheckCommand: azure check
        /home/runner/work/_temp/b3d8f1b5-51e1-4a01-a19d-6522185de758.sh: line 1: appCdnProfileName: command not found
        Error: Process completed with exit code 127.

## 7. .github/workflows/build-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/build-job.yml

### Errors and issues:

    Run npm install @mw/cli@latest -g
    npm ERR! code E404
    npm ERR! 404 Not Found - GET https://registry.npmjs.org/@mw%2fcli - Not found
    npm ERR! 404 
    npm ERR! 404  '@mw/cli@latest' is not in the npm registry.
    npm ERR! 404 You should bug the author to publish it (or use the name yourself!)
    npm ERR! 404 
    npm ERR! 404 Note that you can also install from a
    npm ERR! 404 tarball, folder, http url, or git url.


## 8. .github/workflows/compliance-audit-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/compliance-audit-job.yml

### Errors and issues:

    Run npm install @mw/cli@latest -g
    npm ERR! code E404
    npm ERR! 404 Not Found - GET https://registry.npmjs.org/@mw%2fcli - Not found
    npm ERR! 404 
    npm ERR! 404  '@mw/cli@latest' is not in this registry.
    npm ERR! 404 
    npm ERR! 404 Note that you can also install from a
    npm ERR! 404 tarball, folder, http url, or git url.



## 9. .github/workflows/compliance-only.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/compliance-only.yml

### Errors and issues:

    Run npm install @mw/cli@latest -g
    npm ERR! code E404
    npm ERR! 404 Not Found - GET https://registry.npmjs.org/@mw%2fcli - Not found
    npm ERR! 404 
    npm ERR! 404  '@mw/cli@latest' is not in this registry.
    npm ERR! 404 
    npm ERR! 404 Note that you can also install from a
    npm ERR! 404 tarball, folder, http url, or git url.


## 10. .github/workflows/deploy-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/deploy-job.yml

### Errors and issues:
`Run azure/webapps-deploy@v2`

`Error: Deployment Failed, Error: No credentials found. Add an Azure login action before this action. For more details refer https://github.com/azure/login`


## 11. .github/workflows/hello_world.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/hello_world.yml

This file runs without any issues.

## 12. .github/workflows/init-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/init-job.yml

### Errors and issues:

    Run RC_RESULT=0
    ##vso[task.logissue type=error]CF_DELIVERY_ACCESS_TOKEN is Empty!
    ##vso[task.logissue type=error]CF_ENVIRONMENT is Empty!
    ##vso[task.logissue type=error]CF_SPACE_ID is Empty!
    ##vso[task.logissue type=error]CF_PREVIEW_ACCESS_TOKEN is Empty!
    ##vso[task.logissue type=error]RUN_MODE is Empty!
    ##vso[task.logissue type=error]SITE_LANG is Empty!
    ##vso[task.logissue type=error]AZUREDDANAME is Empty!
    ##vso[task.logissue type=error]NODEVERSION is Empty!
    Error: Process completed with exit code 1.

## 13.  .github/workflows/init-pr-verify-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/init-pr-verify-job.yml

### Errors and issues:

    CDN Variables
    Run CDN_PROFILE="$(appCdnProfileName)"
    /home/runner/work/_temp/06e8b295-47b2-499c-b6d5-e3e062bae261.sh: line 1: appCdnProfileName: command not found
    Error: Process completed with exit code 127.

## 14. .github/workflows/pr-verify-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/pr-verify-job.yml

### Errors and issues:

    Run npm install
    npm install
    shell: /usr/bin/bash -e {0}
    env:
        npm_config_cache: $(Pipeline.Workspace)/.npm
        workingDir: $(System.DefaultWorkingDirectory)
        command: ci
    npm WARN saveError ENOENT: no such file or directory, open '/home/runner/work/brand-digital-presence-engineering-gh-actions/brand-digital-presence-engineering-gh-actions/package.json'
    npm notice created a lockfile as package-lock.json. You should commit this file.
    npm WARN enoent ENOENT: no such file or directory, open '/home/runner/work/brand-digital-presence-engineering-gh-actions/brand-digital-presence-engineering-gh-actions/package.json'
    npm WARN brand-digital-presence-engineering-gh-actions No description
    npm WARN brand-digital-presence-engineering-gh-actions No repository field.
    npm WARN brand-digital-presence-engineering-gh-actions No README data
    npm WARN brand-digital-presence-engineering-gh-actions No license field.

    up to date in 0.347s
    found 0 vulnerabilities

    Error: The operation was canceled.

## 15. .github/workflows/pr-verify.yml


Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/pr-verify.yml

```mermaid

    flowchart LR
        A0(Init) --> 
        B0(Audit) --> 
        C0(VerifyPR)

```

### Errors and issues:

    Annotations

    Init
    Can't find 'action.yml', 'action.yaml' or 'Dockerfile' under '/home/runner/work/brand-digital-presence-engineering-gh-actions/brand-digital-presence-engineering-gh-actions/.github/workflows/pr-verify-job.yml'. Did you forget to run actions/checkout before running your local action?

## 16. .github/workflows/promote-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/promote-job.yml

### Errors and issues: 

    Run npm install @mw/cli@latest -g
    npm install @mw/cli@latest -g
    shell: /usr/bin/bash -e {0}
    env:
        mwHealthCheckCommand: web health check
        command: custom
        customRegistry: useFeed
        customFeed: MW-reusable-components
        customCommand: install @mw/cli@latest -g
    npm ERR! code E404
    npm ERR! 404 Not Found - GET https://registry.npmjs.org/@mw%2fcli - Not found
    npm ERR! 404 
    npm ERR! 404  '@mw/cli@latest' is not in this registry.
    npm ERR! 404 
    npm ERR! 404 Note that you can also install from a
    npm ERR! 404 tarball, folder, http url, or git url.


## 17. .github/workflows/quality-job.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/quality-job.yml

### Errors and issues: 
    Run montudor/action-zip@v1
    Error: Container action is only supported on Linux

## 18. .github/workflows/rollback.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/rollback.yml

### Errors and issues: 
    Annotations
    1 error
    Rollback
    Can't find 'action.yml', 'action.yaml' or 'Dockerfile' under '/home/runner/work/brand-digital-presence-engineering-gh-actions/brand-digital-presence-engineering-gh-actions/.github/workflows/init-job.yml'. Did you forget to run actions/checkout before running your local action?

## 19.  .github/workflows/test-action.yml
### Link to the repository file:

https://github.com/procter-gamble/brand-digital-presence-engineering-gh-actions/blob/new-jobs/.github/workflows/test-action.yml

### Errors and issues:

    Annotations
    1 error 
    Test-Acton
    Can't find 'action.yml', 'action.yaml' or 'Dockerfile' under '/home/runner/work/brand-digital-presence-engineering-gh-actions/brand-digital-presence-engineering-gh-actions/.github/workflows/hello_world.yml'. Did you forget to run actions/checkout before running your local action?