#!/bin/bash
# source .env
set -x

INPUT_FILE="inputfile.csv"
OUTPUT_FILE="outputfile.csv"
git config --global user.email "kumar.mk.24@pg.com"
git config --global user.name "Manoj Kumar"
migrate_branch() {
    local ado_project="$1" ado_repo="$2" github_repo="$3" branch="$4"
    
    echo "Migrating $branch from $ado_project/$ado_repo to $github_repo"

    git clone "https://x-access-token:$azure_pat@dev.azure.com/pg-consumer/$ado_project/_git/$ado_repo" temp_repo || return 1
    cd temp_repo || return 1

    git remote add gitorigin "https://x-access-token:$github_pat@github.com/procter-gamble/$github_repo.git"
    
    # Fetch all branches from both remotes
    git fetch --all

    # Checkout the branch, creating it if it doesn't exist
    git checkout "$branch" || git checkout -b "$branch" origin/"$branch" || return 1

    # Pull latest changes from ADO
    git pull origin "$branch"

    # Check if the branch exists on GitHub
    if git ls-remote --exit-code --heads github "$branch" > /dev/null 2>&1; then
        # If it exists, merge the GitHub version
        git pull gitorigin "$branch" --no-edit
    fi

    # Copy .github folder from main or master branch of GitHub
    git checkout gitorigin/main -- .github

    rm -f .npmrc

    # Rename the branch if it is dev or develop to development
    if [[ "$branch" == "dev" || "$branch" == "develop" ]]; then
        git branch -M development
        branch="development"
    elif [[ "$branch" == "stage" ]]; then
        git branch -M staging
        branch="staging"
    fi
    
    git add .
    git commit -m "Updated branch with latest changes, added .github files, and removed .npmrc" || true

    # Force push to GitHub to ensure the branch is updated
    git push -f gitorigin "$branch":"$branch" || return 1

    cd ..
    rm -rf temp_repo
    return 0
}

echo "ADOProjectName,ADORepo,GitHubRepo,Branch,Status" > "$OUTPUT_FILE"

while IFS=',' read -r ado_project ado_repo github_repo branch
do
    ado_project=$(echo "$ado_project" | tr -d '\r' | xargs)
    ado_repo=$(echo "$ado_repo" | tr -d '\r' | xargs)
    github_repo=$(echo "$github_repo" | tr -d '\r' | xargs)
    branch=$(echo "$branch" | tr -d '\r' | xargs)

    if migrate_branch "$ado_project" "$ado_repo" "$github_repo" "$branch"; then
        status="Success"
    else
        status="Failed"
    fi

    echo "$ado_project,$ado_repo,$github_repo,$branch,$status" >> "$OUTPUT_FILE"
done < <(tail -n +2 "$INPUT_FILE")

echo "Migration completed. Check $OUTPUT_FILE for results."