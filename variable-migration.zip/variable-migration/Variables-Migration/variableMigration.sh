# set -x
source .env
while IFS=, read -r projectname ado_repo github_repo
do
 github_repo=$(echo $github_repo | tr -d '\r')
  curl -s -u:$azure_pat "https://dev.azure.com/pg-consumer/$projectname/_apis/distributedtask/variablegroups?api-version=7.1-preview.2">variables.json
  total_variable_groups=$(jq '.count' variables.json)
  for ((j=0;j<$total_variable_groups;j++));
  do
    variableGroupName=$(jq -r ".value[$j].name" variables.json)
    environments=("production" "development" "shared" "staging")
    for environment in "${environments[@]}"
    do
      if [[ $variableGroupName =~ $environment ]];then
        environment="$github_repo"-"$environment"
        curl -L \
        -X PUT \
        -H "Accept: application/vnd.github+json" \
        -H "Authorization: Bearer $github_pat" \
        -H "X-GitHub-Api-Version: 2022-11-28" \
        https://api.github.com/repos/procter-gamble/$github_repo/environments/$environment 
        readarray -t keys < <(cat variables.json| jq -r ".value[$j].variables|keys_unsorted[]")
        for ((k=0; k<${#keys[@]}; k++)); 
        do
          key="${keys[$k]}"
          key=$(echo ${keys[$k]}|sed 's/\r$//')
          value=$(cat variables.json| jq -r ".value[$j].variables.$key.value")
          if [ -z $value ];then
            value="empty"
          fi
          curl -L -X POST -H "Accept: application/vnd.github+json" -H "Authorization: Bearer $github_pat" -H "X-GitHub-Api-Version: 2022-11-28" "https://api.github.com/repos/procter-gamble/$github_repo/environments/$environment/variables" -d '{"name":"'$key'","value":"'$value'"}'
          echo "variable successfully created"
        done
      fi
    done
  done
done < project_details.csv



