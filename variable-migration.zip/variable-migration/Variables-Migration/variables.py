import pandas as pd
import requests
import json
from dotenv import load_dotenv
import os

# Load variables from .env
load_dotenv()
azure_pat = os.getenv("azure_pat")
# Read project details from CSV file
file = 'project_details.csv'
readerObj = pd.read_csv(file)

for index, row in readerObj.iterrows():
    project_name = row['projectname']
    ado_reponame = row['ado_repo']

    #Getting the ADO Variable Grups
    response = requests.get(f"https://dev.azure.com/pg-consumer/{project_name}/_apis/distributedtask/variablegroups?api-version=7.1-preview.2", auth=("", azure_pat))
    variables = response.json()
    # print(variables,"Vars")
    total_variable_groups = variables["count"]
    print(total_variable_groups)
    for j in range(total_variable_groups):
        variableGroupName = variables["value"][j]["name"]
        keys = list(variables["value"][j]["variables"].keys())
        for key in keys:
            value = variables["value"][j]["variables"][key]["value"]
            if not value:
                value = "empty"
            data = {"name": key, "value": value}
            print(f"variable created -{key}")
            data=json.dumps('azvariable.json')




