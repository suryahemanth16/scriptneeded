import pandas as pd
import requests
import json
from dotenv import load_dotenv
import os

# Load variables from .env
load_dotenv()
azure_pat = os.getenv("azure_pat")
github_pat = os.getenv("github_pat")
# Read project details from CSV file
file = 'project_details.csv'
readerObj = pd.read_csv(file)

for index, row in readerObj.iterrows():
    project_name = row['projectname']
    ado_reponame = row['ado_repo']
    github_repo = row['github_repo']
    #Getting the ADO Variable Grups
    response = requests.get(f"https://dev.azure.com/pg-consumer/{project_name}/_apis/distributedtask/variablegroups?api-version=7.1-preview.2", auth=("", azure_pat))
    variables = response.json()
    # print(variables,"Vars")
    total_variable_groups = variables["count"]
    print(total_variable_groups)
    for j in range(total_variable_groups):
        variableGroupName = variables["value"][j]["name"]
        environments = ["production", "development", "shared", "staging"]
        for env in environments:
            if env in variableGroupName:
                environment = f"{github_repo}-{env}"
                headers = {
                    "Accept": "application/vnd.github+json",
                    "Authorization": f"Bearer {github_pat}",
                    "X-GitHub-Api-Version": "2022-11-28"
                }
                # Adding the ADO Variable Groups to GitHub
                requests.put(f"https://api.github.com/repos/procter-gamble/{github_repo}/environments/{environment}", headers=headers)
                print(f"successfully created environment {environment} in {github_repo}")

                keys = list(variables["value"][j]["variables"].keys())
                for key in keys:
                    value = variables["value"][j]["variables"][key]["value"]
                    if not value:
                        value = "empty"
                    data = {"name": key, "value": value}
                    requests.post(f"https://api.github.com/repos/procter-gamble/{github_repo}/environments/{environment}/variables", headers=headers, data=json.dumps(data))
                    print(f"variable created -{key}")




