# Load variables from .env
$azure_pat = Get-Content .env

# Read project details from CSV file
$file = "project_details.csv"
$readerObj = Import-Csv $file

# Initialize an empty array to store variable data
$all_variables = @()

foreach ($row in $readerObj) {
    $project_name = $row.projectname
    $ado_reponame = $row.ado_repo

    # Getting the ADO Variable Groups
    $response = Invoke-RestMethod -Uri "https://dev.azure.com/pg-consumer/$project_name/_apis/distributedtask/variablegroups?api-version=7.1-preview.2" -Headers @{Authorization = "Basic $azure_pat"}
    $variables = $response.value

    foreach ($var in $variables) {
        $variable_group_name = $var.name
        $group_variables = $var.variables

        foreach ($key in $group_variables.Keys) {
            $value = $group_variables[$key].value
            $value = if ($value) { $value } else { "empty" }
            $variable_data = @{
                project = $project_name
                variable_group = $variable_group_name
                variable_name = $key
                variable_value = $value
            }
            $all_variables += $variable_data
        }
    }
}

# Write all_variables to a JSON file
$all_variables | ConvertTo-Json | Set-Content -Path azvariables.json

Write-Host "Variables saved to azvariables.json"
