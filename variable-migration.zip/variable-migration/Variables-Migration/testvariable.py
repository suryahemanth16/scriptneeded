import pandas as pd
import requests
import json
from dotenv import load_dotenv
import os

# Load variables from .env
load_dotenv()
azure_pat = os.getenv("azure_pat")

# Read project details from CSV file
file = 'project_details.csv'
readerObj = pd.read_csv(file)

# Initialize an empty list to store variable data
all_variables = []

for index, row in readerObj.iterrows():
    project_name = row['projectname']
    ado_reponame = row['ado_repo']

    # Getting the ADO Variable Groups
    response = requests.get(f"https://dev.azure.com/pg-consumer/{project_name}/_apis/distributedtask/variablegroups?api-version=7.1-preview.2", auth=("", azure_pat))
    variables = response.json()
    print(response.content)

    for j in range(variables["count"]):
        variable_group_name = variables["value"][j]["name"]
        group_variables = variables["value"][j]["variables"]

        for key, value_obj in group_variables.items():
            value = value_obj.get("value", "empty")
            variable_data = {
                "project": project_name,
                "variable_group": variable_group_name,
                "variable_name": key,
                "variable_value": value
            }
            all_variables.append(variable_data)

# Write all_variables to a JSON file
with open('azvariables.json', 'w') as json_file:
    json.dump(all_variables, json_file, indent=4)

print("Variables saved to azvariables.json")
